import 'package:flutter/material.dart';

class Task1 extends StatefulWidget {
  const Task1({super.key});

  @override
  State<Task1> createState() => _Task1State();
}

class _Task1State extends State<Task1> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body:Center(
        child: ClipRRect(borderRadius: BorderRadius.circular(300),
          child: Stack(
            children: [
              Container(
                height: 300,
                width: 300,
                decoration:
                BoxDecoration(color: Colors.blueGrey, shape: BoxShape.circle),
              ),
              Container(
                height: 100,
                width: 100,
                decoration: BoxDecoration(
                    color: Colors.red, shape: BoxShape.circle),
                margin: EdgeInsets.only(),
              )
            ],
          ),
        ),
      ),

    );
  }
}
