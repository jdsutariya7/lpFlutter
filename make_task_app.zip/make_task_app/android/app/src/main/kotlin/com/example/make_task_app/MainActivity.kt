package com.example.make_task_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
